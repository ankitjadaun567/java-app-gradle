##### build the project

    gradle build
